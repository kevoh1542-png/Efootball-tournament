# eFootball Tournament — starter website

Configured from your details:
- Tournament name: eFootball Tournament
- Format: League and knockout
- Eligible platform: eFootball Mobile only
- Entry fee: KSh 150
- M-PESA number provided: 0741404837
- Prizes: 1st KSh 800, 2nd KSh 500, 3rd KSh 200
- Registration, fixtures, results, standings, bracket notes, and admin demo

## Important status
This is a browser-only prototype, not yet a production multi-user tournament platform. Data is stored in the current browser localStorage, so separate phones do not share data. Admin authentication in this file is only a demo gate and is not secure. Payment instructions do not verify payment automatically. Before accepting public registrations or money, migrate to a hosted database, enforce authentication/authorization on the server, and add server-side M-PESA Daraja integration with secrets stored only as server environment variables. Confirm that the M-PESA number above is correct and belongs to the tournament organiser before publishing it publicly.

## Publish a free static preview with GitHub Pages
1. Create a GitHub repository named `efootball-tournament` on https://github.com/new . A public repo is easiest for GitHub Pages.
2. Upload `index.html` to the repository root.
3. Open Settings → Pages. Under Build and deployment, choose deploy from branch, select `main` and `/ (root)`, then Save.
4. After GitHub Pages deploys it, the site will have a URL like `https://YOUR-USERNAME.github.io/efootball-tournament/`.

The static preview is not the production launch because its database and login are device-local/client-side. Do not use a real admin password in this prototype.
